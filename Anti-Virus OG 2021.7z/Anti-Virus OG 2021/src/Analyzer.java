import java.util.ArrayList;

public class Analyzer {

    public int analyze(String hashValue, ArrayList<String> virusDefinitions){

        /** Vergleicht den Hashwert der zu scannenden Datei mit der VirusDB **/

        int index = -1;

        for(int i=0;i<virusDefinitions.size();i++){
            if(hashValue.equals(virusDefinitions.get(i))){
                index = i;
                return index;
            }
        }
        return index;
    }
}

