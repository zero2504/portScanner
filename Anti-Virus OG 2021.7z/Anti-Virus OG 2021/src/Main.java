import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import javax.swing.JOptionPane;

public class Main {

    public static void main(String args[]) throws IOException {

        AntiScanner antiScanner = new AntiScanner();
        String hashValue = antiScanner.fileChooser();

        long startTime = antiScanner.startTime();
        FileHandlerData fhd = new FileHandlerData();
        boolean status = fhd.readVirusDefinition();

        Analyzer logic = new Analyzer();
        logic.analyze(hashValue, AntiScanner.virusDefinitions);

        File file = new File(AntiScanner.file.getPath());
        if (status) {

            int index = logic.analyze(hashValue, AntiScanner.virusDefinitions);

            if (index == -1) {
                System.out.println("Clean File.");
                JOptionPane.showMessageDialog(null, AntiScanner.fileName+" file doesn't contain a virus.\nFile MD5: "+hashValue+"\nis not found in virus definitions" + " \nSize: " + AntiScanner.fileSize+ " bytes \n", "Scan Complete",JOptionPane.INFORMATION_MESSAGE);
            } else {
                System.out.println("Virus Detected!");
                JOptionPane.showMessageDialog(null,
                        AntiScanner.fileName+" File contains a virus.\n"
                                + "File MD5: "+hashValue+"\nis found in virus definitions\n" + " Size: " + AntiScanner.fileSize+ " bytes\n"
                                + "Virus Name: "+AntiScanner.virusNames.get(index)+"\nVirus Type: "+AntiScanner.virusTypes.get(index),
                        "Virus Detected!",JOptionPane.WARNING_MESSAGE);
                int result = JOptionPane.showConfirmDialog(null, "Delete malicious data?", "Safe delete", JOptionPane.OK_CANCEL_OPTION);
                if(result == JOptionPane.OK_OPTION) {
                    Files.delete(file.toPath());
                    JOptionPane.showMessageDialog(null, "Successfully delete", "Clean Up", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null,"You don't delete the virus! ","Idiot",JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } else {
            System.out.println("No DataBase, please retry. For more information contact @Ogulcan Ugur");
        }
        System.out.println(antiScanner.endTime(startTime)+ " Sekunden");
    }
}
