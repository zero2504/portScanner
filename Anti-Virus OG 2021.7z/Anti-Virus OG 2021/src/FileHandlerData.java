import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileHandlerData {

    private  String line1 = "N/A virusName";
    private  String line2 = "N/A virusTyp";


    public boolean readVirusDefinition() throws FileNotFoundException {

        /** Gibt eine Array-List zurück und
         schreibt die Hashwerte in die jeweiligen Listen. **/

        //Path path = Paths.get("C:\\Users\\UgurOgu\\IdeaProjects\\Anti-Virus OG 2021\\src\\VirusDataBase\\db.txt");
        Path path = Paths.get("C:\\Users\\UgurOgu\\IdeaProjects\\Anti-Virus OG 2021\\src\\VirusDataBase\\BigDB.txt");
        BufferedReader bufferedReader = new BufferedReader(new FileReader(path.toString()));

        try {
            String line = bufferedReader.readLine();
            while (line != null) {
                String[] lineArray = line.split("\\|");
                AntiScanner.virusDefinitions.add(lineArray[0]);
                if(lineArray[1].isEmpty() || lineArray[2].isEmpty()) {
                    line1 = lineArray[1];
                    line2 = lineArray[2];
                }
                AntiScanner.virusNames.add(lineArray[1]);
                AntiScanner.virusTypes.add(lineArray[2]);
                line = bufferedReader.readLine();
            }

            bufferedReader.close();

        } catch(FileNotFoundException e) {
            return false;
        } catch(IOException e){
            System.out.println("IO Exception in FileHandler");
            return false;
        }
        return true;
    }
}

