import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.security.*;
import java.util.ArrayList;
import javax.swing.JFileChooser;


public class AntiScanner {

    public static ArrayList<String> virusDefinitions = new ArrayList<String>();
    public static ArrayList<String> virusNames = new ArrayList<String>();
    public static ArrayList<String> virusTypes = new ArrayList<String>();
    public static String fileName = "";
    public static File file = null;
    public static long fileSize;

    public String fileChooser() {

        JFileChooser chooser = new JFileChooser();
        chooser.showDialog(null, "Select Data");
        fileName = chooser.getSelectedFile().getName();
        file = chooser.getSelectedFile();
        fileSize = chooser.getSelectedFile().length();
        return getFileHash(chooser.getSelectedFile());
    }

    public  String getHash(byte [] inputBytes, String algorithm){

        String hashValue = "";

        try {
            MessageDigest messageDigest = MessageDigest.getInstance(algorithm);
            messageDigest.update(inputBytes);
            byte[] diggestBytes = messageDigest.digest();
            for ( int i = 0; i < diggestBytes.length; i++ ){
                hashValue += ( Integer.toHexString( diggestBytes[i]&0xff));
            }
            System.out.println(hashValue);

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return hashValue;
    }

     public String getFileHash(File file){
        try{
            byte[] fileBytes = Files.readAllBytes(file.toPath());
            return getHash(fileBytes,"MD5");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
     }

     public long startTime() {

        long startTime = System.currentTimeMillis();
         return startTime;
     }

     public long endTime(long startTime) {

        long endTime = System.currentTimeMillis();
        long result = (endTime - startTime) / 1000;
        return result;
     }


}
